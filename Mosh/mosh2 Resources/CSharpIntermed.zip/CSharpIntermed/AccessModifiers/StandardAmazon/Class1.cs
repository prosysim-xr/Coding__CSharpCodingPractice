﻿using System;

namespace StandardAmazon
{
    public class Class1
    {
    }
}
