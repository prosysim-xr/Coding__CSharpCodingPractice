﻿namespace AccessModifiers_Core
{
    public class GoldCustomer : Customer
    {

    }

    class Program
    {
        static void Main(string[] args)
        {
            var customer = new Customer();

        }
    }
}
