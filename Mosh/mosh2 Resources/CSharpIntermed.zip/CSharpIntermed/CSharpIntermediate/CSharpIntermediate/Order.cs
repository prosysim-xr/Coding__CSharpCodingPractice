﻿namespace CSharpIntermediate
{
    public class Order
    {
        
    }
}