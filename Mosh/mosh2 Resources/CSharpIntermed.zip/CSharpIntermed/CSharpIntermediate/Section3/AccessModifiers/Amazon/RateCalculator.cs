﻿
namespace Amazon
{
    internal class RateCalculator
    {
        public int Calculate()
        {
            return 0;
        }
    }
}
