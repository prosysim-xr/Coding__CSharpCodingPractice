﻿
namespace Constructors
{
    class Program
    {
        static void Main(string[] args)
        {
            var car = new Car("XYZ1234");


        }
    }
}
