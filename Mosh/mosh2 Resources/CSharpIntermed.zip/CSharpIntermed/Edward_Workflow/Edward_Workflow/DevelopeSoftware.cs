﻿namespace Edward_Workflow
{
    class DevelopeSoftware : IActivity
    {
        public void Execute()
        {
            System.Console.WriteLine("In Development");
        }
    }
}
