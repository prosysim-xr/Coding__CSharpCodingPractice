﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Edward_Workflow
{
    public interface IActivity
    {
        void Execute();
    }
}
