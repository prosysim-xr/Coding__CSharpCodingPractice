﻿namespace Edward_Workflow
{
    class RequirementsAnalyze : IActivity
    {
        public void Execute()
        {
            System.Console.WriteLine("Requirements are under review");
        }
    }
}
