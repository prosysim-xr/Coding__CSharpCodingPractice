﻿namespace Edward_Workflow
{
    class TestSoftware : IActivity
    {
        public void Execute()
        {
            System.Console.WriteLine("Software is under testing");
        }
    }
}
