﻿using System;
using System.Collections.Generic;

namespace NastiaWorkflow
{
    public interface IActivity
    {
        void Execute();
    }

    public class VideoUpload : IActivity
    {
        public void Execute()
        {
            Console.WriteLine("Uploading video...");
        }
    }

    public class CallWebService : IActivity
    {
        public void Execute()
        {
            Console.WriteLine("Calling web service...");
        }
    }

    public class SendMail : IActivity
    {
        public void Execute()
        {
            Console.WriteLine("Sending mail...");
        }
    }

    public class ChangeStatus : IActivity
    {
        public void Execute()
        {
            Console.WriteLine("Changing status...");
        }
    }

    public class WorkFlow
    {
        private readonly List<IActivity> _activities;
        public IReadOnlyCollection<IActivity> Activities
        {
            get { return _activities.AsReadOnly(); }
        }

        public WorkFlow()
        {
            _activities = new List<IActivity>();
        }

        public void AddActivity(IActivity activity)
        {
            if (activity == null)
                throw new NullReferenceException("Invalid activity specified");
            else
            {
                _activities.Add(activity);
            }
        }


        public void Clear()
        {
            _activities.Clear();
        }
    }


    public class WorkFlowEngine
    {

        public void Run(WorkFlow workFlow)
        {
            if (workFlow == null)
                throw new NullReferenceException("Null workflow");
            else
            {
                if (workFlow.Activities.Count == 0)
                {
                    Console.WriteLine("No work to be done");
                }
                else
                {
                    foreach (var Activity in workFlow.Activities)
                    {
                        Activity.Execute();
                    }
                }
            }
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var WorkFlow = new WorkFlow();
                WorkFlow.AddActivity(new CallWebService());
                WorkFlow.AddActivity(new ChangeStatus());
                WorkFlow.AddActivity(new VideoUpload());
                WorkFlow.AddActivity(new SendMail());

                var workFlowEngine = new WorkFlowEngine();
                workFlowEngine.Run(WorkFlow);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}